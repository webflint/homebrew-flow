#!/bin/bash

function Github::Pr.url {
  local owner=$1 repo=$2 number=$3
  echo "https://github.com/${owner}/${repo}/pull/${number}"
}

function Github::Repo.url {
  echo "https://github.com/$(Git::Repo.owner)/$(Git::Repo.name)"
}

function Github::Branch.url {
  local owner=$1 repo=$2 name=$3
  echo "https://github.com/${owner}/${repo}/tree/${name}"
}

function Github::Branch.compare_url {
  local source target story_id title body url parameters
  target=${1:-$(Git::Branch.name)}
  source=${2:-$(Git::Branch.name)}
  story_id=$(Git.story_id "$source")

  title=$(Backend::Story.title "$story_id")
  description=$(Backend::Story.description "$story_id")
  url=$(Backend::Story.url "$story_id")
  story_link=$(String.encode "[$title]($url)")
  encoded_description=$(String.encode "$description")
  body="$story_link%0A%0A$encoded_description"

  url="http://github.com/$(Git::Repo.owner)/$(Git::Repo.name)/compare/${target}...${source}"
  parameters="title=$(String.encode "[$story_id] $title")&body=$body"
  echo "$url?$parameters"
}

function Github.send {
  local query=$1
  curl -s \
      -X POST \
      'https://api.github.com/graphql' \
      -H "Authorization: bearer $GH_TOKEN" \
      -H "Content-Type: application/json" \
      -H "Accept: application/vnd.github.merge-info-preview+json" \
      -d "$(Github.query "$query")"
}

function Github.query {
  local input=$1
  cat << EOF
    {"query":
      "query{$(String.escape_newline "$input")}"
    }
EOF
}

function Github::User.login {
  Github.send "$(Github::Query.login)" | jq -r '.data.viewer.login'
}

function Github::Pr.get {
  # local owner=$1 repo=$2 number=$3
  Github.send "$(Github::Query.pr)"
}

function Github::User.prs {
  Github.send "$(Github::Query::User.prs)"
}

function Github::Query.pr {
  owner=$(Git::Repo.owner)
  repo=$(Git::Repo.name)
  branch=$(Git::Branch.name)
  cat << EOF
    repository(owner:\"$owner\", name:\"$repo\") {
      pullRequests(first: 10, headRefName: \"$branch\") {
        edges {
          node {
            createdAt,
            closed,
            title,
            url,
            baseRefName,
            reviewDecision,
            mergeable,
            mergeStateStatus,
            comments {totalCount},
            participants {totalCount}
            reviewRequests {totalCount}
            reviews {totalCount}
          }
        }
      }
    }
EOF
}

function Github::Query.login {
  cat << EOF
    viewer {login}
EOF
}

function Github::Query::User.prs {
  cat << EOF
    viewer {
      pullRequests(first: 10, states: OPEN) {
          edges {
              node {
                title,
                url,
                baseRefName,
                headRefName,
                closed,
                createdAt,
                mergeable,
                mergeStateStatus,
                comments {totalCount},
                participants {totalCount}
                reviewRequests {totalCount}
                reviews {totalCount}
              }
          }
      }
    }
EOF
}
