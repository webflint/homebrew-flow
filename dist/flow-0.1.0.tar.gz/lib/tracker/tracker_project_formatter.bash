#!/bin/bash

function Tracker::Project::Formatter.console {
  input=$(< /dev/stdin)
  local id url name description
  id=$(JQ.print "$input" .id)
  url=$(Tracker::Project.url "$id")
  name=$(JQ.print "$input" .name)
  description=$(JQ.print "$input" .description)

  echo -e name: '\t'"$(Print.highlight "$name")"
  echo -e url:'\t'"$url"
  # echo -e id: '\t'"$id"
  echo
  echo -e '\t'"$description"
}

function Tracker::Project::Formatter.markdown {
  input=$(< /dev/stdin)
  local id url name
  id=$(JQ.print "$input" .id)
  url=$(Tracker::Project.url "$id")
  name=$(JQ.print "$input" .name)

  echo "[$name]($url)"
}

function Tracker::Project::Formatter.markdown2 {
  input=$(< /dev/stdin)
  local id url name description
  id=$(JQ.print "$input" .id)
  url=$(Tracker::Project.url "$id")
  name=$(JQ.print "$input" .name)
  description=$(JQ.print "$input" .description)

  echo "# $name"
  echo
  echo "## $url"
  echo
  echo "${description}"
  echo
}
