#!/bin/bash

function Tracker::Story::Comment.list {
  declare -r story_id="$1"
  declare -r fields='comments(text,person(name))'
  # echo "${endpoint}?fields=${fields}"
  project_id=$(Flow.project_id)
  # local endpoint="/projects/${project_id}/stories/${story_id}/comments"

  Tracker::Story.get "$story_id" "$fields" \
    | jq -r '.comments[] | "\(.person.name) - \(.text)"'
  # Tracker.get "${endpoint}?fields=${fields}"
}

function Tracker::Story::Comment.create {
  local story_id="$1"
  local text="$2"
  local project_id
  # TODO: Need to source the project from the story
  project_id=$(Flow.project_id)
  local endpoint="/projects/${project_id}/stories/${story_id}/comments"

  data="{\"text\":\"$text\"}"
  Tracker.create "$endpoint" "$data"
}
