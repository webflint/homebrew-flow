#!/bin/bash

function Tracker::Me.get {
  fields=${1:-id}
  Tracker.get "/me?fields=${fields}"
}

function Tracker::Me.id {
  fields=id
  Tracker::Me.get "${fields}" \
    | jq -r '.id'
}

function Tracker::Me.account_id {
  fields='accounts(id)'
  Tracker::Me.get "${fields}" \
    | jq -r '.accounts[0].id'
}
