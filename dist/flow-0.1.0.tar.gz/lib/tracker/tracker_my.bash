#!/bin/bash

function Tracker::My.activity {
  local after=$1
  local person_id
  person_id=$(Tracker::Me.id)
  fields=message,primary_resources
  Tracker.get "/my/activity?occurred_after=${after}&fields=${fields}"
}

function Tracker::My.people {
  Tracker::My::Projects.members
}

function Tracker::My.wip {
  local person_id=${1:-$(Tracker::Me.id)}
  local filter="mywork:${person_id}"
  Tracker::My::Projects.stories "$filter"
}

function Tracker::My.stories {
  local person_id=${1:-$(Tracker::Me.id)}
  local filter="requester:$person_id%20-state:accepted"
  Tracker::My::Projects.stories "$filter"
}

function Tracker::My::Projects.stories {
  local filter=$1
  local fields="id,url,name,current_state,story_type,estimate,description,owners(name,initials),requested_by(name,initials),project(name),cycle_time_details,labels(name),pull_requests"
  Tracker::My::Projects.search "Stories" "$filter" "'$fields'"
}

function Tracker::My::Projects.members {
  Tracker::My::Projects.search "Membership" "'person(username)'" \
    | jq '[.[].person] | unique'
}

function Tracker::My::Projects.search {
  local command=${1:-}
  shift
  local args=("$@")

  # TODO: document this filter
  local exclude_project_filter='zzz - '
  declare -a project_ids
  IFS=" " read -r -a project_ids <<< "$(Tracker::Project.list \
    | jq -r  --arg filter "$exclude_project_filter" '[.[] | select(.name | (startswith($filter) | not) )] | map(.id | tostring) | join(" ")')"

  # NOTE: tracker api rate limits if we batch more than ~15 commands to the aggregator endpoint
  local data endpoints end_index
  local project_count=${#project_ids[@]}
  local batch_size=15
  local entries='[]'
  local endpoint
  for ((i=0; i < project_count; i+=batch_size));
  do
    endpoints=()
    end_index=$((project_count < i+batch_size ? project_count : i+batch_size))
    for ((n=i; n < end_index; n+=1));
    do
      project_id=${project_ids[n]}
      endpoint=$(eval "Tracker::Project::$command.endpoint" "$project_id" "${args[@]}")
      endpoints+=("\"/services/v5${endpoint}\"")
    done

    data=[$(Array.join , "${endpoints[@]}")]
    entries=$(Tracker.send POST "/aggregator" "${data}" \
      | jq --argjson entries "$entries" 'to_entries | map(.value) | flatten + $entries')
  done

  echo "$entries"
}
