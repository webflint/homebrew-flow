#!/bin/bash

function Tracker::Project.url {
  local id=$1
  echo "$FLOW_TRACKER_BASE_HTTP_URL/n/projects/${id}"
}

function Tracker::Project.list {
  fields="name"
  Tracker.get "/projects?fields=${fields}"
}

function Tracker::Project.get {
  local id=$1
  local endpoint="/projects/${id}"
  Tracker.get "$endpoint"
}

function Tracker::Project.activity {
  local id=$1
  local after=$2
  local endpoint
  endpoint=$(Tracker::Project::Activity.endpoint "$id" "$after")
  Tracker.get "$endpoint"
}

function Tracker::Project.snapshot {
  local id=$1
  local start_date=$2
  local endpoint
  endpoint=$(Tracker::Project::Snapshot.endpoint "$id" "$start_date")
  Tracker.get "$endpoint"
}

function Tracker::Project.stories {
  local id=$1
  local filter=$2
  local fields=${3:-:default}
  local endpoint
  endpoint=$(Tracker::Project::Stories.endpoint "$id" "$filter" "$fields")
  Tracker.get "$endpoint"
}

function Tracker::Project::Activity.endpoint {
  local id=$1
  local after=${2:-}
  local fields=${3:-:default}
  echo "/projects/${id}/activity?occurred_after=$after&fields=$fields"
}

function Tracker::Project::Stories.endpoint {
  local id=$1
  local filter=${2:-}
  local fields=${3:-:default}
  echo "/projects/${id}/stories?filter=$filter&fields=$fields"
}

function Tracker::Project::Search.endpoint {
  local id=$1
  local filter=${2:-}
  echo "/projects/${id}/search?filter=$filter"
}

function Tracker::Project::Snapshot.endpoint {
  local id=$1
  local start_date=${2:-}
  local fields=${3:-:default}
  echo "/projects/${id}/history/snapshots?start_date=$start_date&fields=$fields"
}
