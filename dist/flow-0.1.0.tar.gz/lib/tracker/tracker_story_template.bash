#!/bin/bash

function Tracker::Story::Template.feature {
  cat << EOM
As a User, so that I can be enabled, make this change

### Acceptance Critiera

**Given**
**When**
**Then**

### Implementation Notes
*
EOM
}

function Tracker::Story::Template.bug {
  cat << EOM
A simple statement about the bug

### Expected Result

### Actual Result

### Reproduction Steps

### Notes
EOM
}

function Tracker::Story::Template.chore {
  cat << EOM
What should we do?

### This chore is done when

EOM
}
