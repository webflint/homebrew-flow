#!/bin/bash

function Backend::Story.branch_name {
  story=$(Tracker::Story.get "$story_id" "name,story_type")
  Tracker::Story.branch_name "$story"
}

function Backend::Story.url {
  Tracker::Story.get "$story_id" "url" \
    | jq -r '.url'
}

function Backend::Story.get {
  local id=$1

  Tracker::Story.get "$id"
}

function Backend::Story.state {
  local id=$1
  Backend::Story.get "$id" | jq -r .current_state
}

function Backend::Story.finish {
  local story_id=$1
  local state data

  state=finished
  data="{\"current_state\": \"${state}\"}"

  Tracker::Story.update "${story_id}" "${data}" 1>/dev/null
}

function Backend::Story.deliver {
  local id=$1
  local state=delivered
  local data="{\"current_state\": \"${state}\"}"

  Tracker::Story.update "${id}" "${data}" 1>/dev/null
}

function Backend::Story.create {
  local project_id=$1 story_type=$2

  Tracker::Story.new "${project_id}" "${story_type}" \
    | jq -r .url
}

function Backend::Story.accept {
  story_id=$1
  declare -r state=accepted
  declare -r data="{\"current_state\": \"${state}\"}"
  Tracker::Story.update "${story_id}" "${data}" 1>/dev/null
}

function Backend::Story.start {
  if [[ "$story_id" != "$branch_story_id" ]]; then
    # find the branch attached to the story in the backend
    branch_name=$(echo "$story" | jq -r '.branches[0].name')

    if [[ -n "$locate_branch" && "$branch_name" == null ]]; then
      branch_name=$(Git::Branch.find "$story_id")
    fi

    if [[ -z "$branch_name" || "$branch_name" == null ]]; then
      flow branch create "$story_id"
    else
      git fetch &> /dev/null
      git checkout "$branch_name"
    fi
  fi

  estimate=$(echo "$story" | jq -r '.estimate')

  if [[ $estimate == null ]]; then
    flow story estimate
  fi

  state=started
  owner_id=$(Tracker::Me.id)
  data="{\"current_state\": \"${state}\", \"owner_ids\": [${owner_id}]}"
  Tracker::Story.update "${story_id}" "${data}" 1>/dev/null
}

function Backend::Story::Branch.list {
  local story_id=$1

  Tracker::Story::Branch.list "$story_id"
}
