#!/bin/bash

function Tracker::Story::Branch.list {
  local story_id=$1
  local fields='branches(owner,repo,name)'
  json=$(Tracker::Story.get "${story_id}" "$fields")
  list=$(echo "${json}" | jq -r '.branches[] | @base64')
  # shellcheck disable=SC2034
  for row in $list; do
    owner=$(JQ.item .owner)
    repo=$(JQ.item .repo)
    name=$(JQ.item .name)
    Github::Branch.url "${owner}" "${repo}" "${name}"
  done
}
