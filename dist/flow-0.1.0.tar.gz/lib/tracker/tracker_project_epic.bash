#!/bin/bash

function Tracker::Project::Epic.url {
  local id=$1
  echo "$FLOW_TRACKER_BASE_HTTP_URL/n/projects/${id}"
}

function Tracker::Project::Epic.list {
  local project_id=$1
  local fields="name,url"
  Tracker.get "/projects/${project_id}/epics?fields=${fields}"
}
