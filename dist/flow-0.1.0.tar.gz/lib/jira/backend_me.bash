#!/bin/bash

function Backend::Me.id {
  Jira::Me.account_id
}

function Backend::Me.get {
  Jira::Me.get
}

function Backend::Me.wip {
  local person_id=$1
  local query

  query=$(String.encode "resolution = unresolved and assignee='$person_id' ORDER BY priority asc, created")
  Jira.get "/3/search?jql=$query" \
    | jq --arg url "$JIRA_WWW_URL" '.issues[] | {key: .key, url:"\($url)/browse/\(.key)", type: .fields.issuetype.name, summary: .fields.summary, status: .fields.status.name}'
}
