#!/bin/bash

function Backend::Project.list {
  Jira::Project.all | jq '.values'
}

function Backend::Project.get {
  local key=$1

  Jira::Project.get "$key"
}
