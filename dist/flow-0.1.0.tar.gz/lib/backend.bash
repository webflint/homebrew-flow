#!/bin/bash

function Backend::Me.id {
  Flow.die "Backend not set.  Please run \"flow config\" to verify your configuration"
}

function Backend::Me.get {
  Flow.die "Backend not set.  Please run \"flow config\" to verify your configuration"
}
