#!/bin/bash

function Backend::Config.story_matcher {
  echo "^[[:upper:]]+[-|/][[:digit:]]+$"
}

# parses the story id from the branch name
# expects -> feature/CORE-123-this-is-my-story-description
function Backend::Config.branch_name_parser {
  cut -d / -f 2
}

function Backend::Me.id {
  Github::User.login
}

function Backend::Me.get {
  Backend::Me.id
}
