#!/bin/bash

for file in "$FLOW_BASE_DIR"/lib/*.*; do
   # shellcheck source=/dev/null
   . "$file"
done

Git::is_repo || Flow.die "Working directory is not a Git repo"

backend=$(Flow::Config.get "backend")
if [ -n "$backend" ]; then
   lowercased_backend=$(String.lower "$backend")
   backend_dir="$FLOW_BASE_DIR/lib/$lowercased_backend"
   if [ ! -d "$backend_dir" ]; then
      Flow.die "Invalid backend: $backend"
   fi

   for file in "$backend_dir"/*.*; do
      # shellcheck source=/dev/null
      . "$file"
   done
fi
