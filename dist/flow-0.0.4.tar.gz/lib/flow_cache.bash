#!/bin/bash

function Flow::Cache.get {
  local key=$1
  file=$(Flow::Cache.file "$key")
  cat "$file" 2>/dev/null
}

function Flow::Cache.get_and_set {
  local command=$1
  if result=$(Flow::Cache.get "$command"); then
    # refresh the cache in the background
    # TODO: implement a proper TTL policy for cache
    { Flow::Cache.set "$command" "$($command)"; } &>/dev/null &
  else
    result=$($command)
    Flow::Cache.set "$command" "$result"
  fi
  echo "$result"
}

function Flow::Cache.set {
  local key=$1 value=$2 cache_file
  cache_file=$(Flow::Cache.file "$key")
  echo "$value" > "$cache_file"
}

function Flow::Cache.delete {
  local key=$1
  cache_file=$(Flow::Cache.file "$key")
  rm "$cache_file" 2>/dev/null || true
}

function Flow::Cache.clear {
  local path
  path=$(Flow::Cache.path)
  rm "$path"/*.flowcache 2>/dev/null
}

function Flow::Cache.path {
  dirname "$(mktemp -u)"
}

function Flow::Cache.file {
  local key=$1 path
  key=$(Flow::Cache.key "$key")
  path=$(Flow::Cache.path)
  echo "$path/$key.flowcache"
}

function Flow::Cache.key {
  local seed=$1
  echo "$seed" | shasum | cut -d' ' -f1
}
