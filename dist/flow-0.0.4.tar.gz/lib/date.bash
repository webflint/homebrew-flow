#!/bin/bash

function Date.today {
  date +%Y-%m-%d
}

function Time.ago {
  local adjustment=$1 tz
  tz=$(date +%z)
  local formatted_tz="${tz:0:3}:${tz:3:5}"

  date -v"$adjustment" +%Y-%m-%dT%H:%M:%S"$formatted_tz"
}

function Time::Adjust.valid {
  [[ $1 =~ ^[+|-][0-9]+[ymwdHMS]$ ]]
}
