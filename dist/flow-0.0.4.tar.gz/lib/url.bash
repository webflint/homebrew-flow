#!/bin/bash

function Url.valid {
  [[ "${1}" =~ ^http(s)*://[^.]+\.[^.]+ ]]
}
