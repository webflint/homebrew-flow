#!/bin/bash

function Shell.open {
  if Shell.has_stdin; then
    url=$(cat -)
  else
    url="$1"
  fi

  if [[ $(uname) == Darwin ]] ; then
    open=open
  else
    open=xdg-open
  fi
  "$open" "$url"
}

function Shell.has_stdin {
  [ -p /dev/stdin ]
}

function Shell.capture_input {
  if Shell.has_stdin; then
    input=$(cat -)
  else
    input="$1"
  fi

  echo "$input"
}
