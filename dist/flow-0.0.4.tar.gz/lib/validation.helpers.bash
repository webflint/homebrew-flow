#!/bin/bash

function Tracker::Validate.editor {
  if [[ -z $(Flow.editor) ]]; then
    Flow.die "Editor not found.  Please set a git core editor or export EDITOR"
  fi
}
