#!/bin/bash

# function exit_trap {
#   # TODO: why does this always trap the prompt?
#   # last_command=${last_command:-''}
#   # echo "[${last_command}] command failed with exit code $?."
#   foo=bar
# }

# keep track of the last executed command
# trap 'last_command=$current_command; current_command=$BASH_COMMAND' DEBUG
# echo an error message before exiting
# trap exit_trap EXIT
# TODO: implement trap cleanup

FLOW_CMD_DIR="$FLOW_BASE_DIR/libexec"

function Flow.prompt {
  local message=${1:-}
  local suggest=${2:-}
  read -r -p "$(Print.highlight '[Flow]') ${message}> " -i "$suggest" -e result
  echo "$result"
}

function Flow.editor {
  declare git_editor
  git_editor=$(git config core.editor)
  echo "${git_editor:-$EDITOR}"
}

function Flow.sub_command {
  local namespace
  namespace=$(basename "$0" | cut -d'.' -f1)
  declare -r sub_command="${1:-}"
  echo "$FLOW_CMD_DIR/${namespace}-${sub_command}"
}

function Flow.is_valid_command {
  [[ -f "$(Flow.sub_command "$@")" ]]
}

function Flow.exec {
  local command
  command="$(Flow.sub_command "$@")"

  if Flow.is_valid_command "$@" >/dev/null; then
    shift
    bash "${command}" "$@"
  else
    Flow.die "${command}: command not found"
  fi
}

function Flow.die {
  # TODO: Improve this with line number
  # http://linuxcommand.org/lc3_wss0140.php
  # http://mywiki.wooledge.org/BashFAQ/101
  echo "$(Print.danger "[Flow]") $1" 1>&2
  exit 1
}

function Flow.modify {
  local text=${1:-}
  local prefix=${2:-flow}
  temp_file=$(File::Temp.create "$prefix" md)
  original_timestamp=$(File.write "${temp_file}" "${text}")
  $(Flow.editor) "$temp_file" > "$(tty)"
  edited_timestamp=$(File.date "$temp_file")
  if [[ "$original_timestamp" == "$edited_timestamp" ]]; then
    Flow.die "Aborting since there were no changes saved."
  fi
  data=$(File.parse "${temp_file}")
  rm "$temp_file"
  echo "$data"
}

function Flow.project_id {
  local project_id
  project_id=$(Flow::Config.get projectid 2> /dev/null)
  if [[ -z ${project_id} ]]; then
    Flow.die "Project id not found"
  fi
  echo "$project_id"
}

function Flow.story_id {
  local story_id=${1:-}

  if [[ -z $story_id ]]; then
    story_id=$(Git.story_id)
  elif Url.valid "$story_id"; then
    story_id=$(echo "$story_id" | rev | cut -d'/' -f1 | rev)
  fi

  if ! Backend::Story.valid_id "$story_id"; then
    Flow.die "Could not resolve story id: $story_id"
  fi

  echo "$story_id"
}
