#!/bin/bash

# resources
# * https://jqplay.org/
# * https://gist.github.com/olih/f7437fb6962fb3ee9fe95bda8d2c8fa4

function JQ.list {
  local result="${1}"
  echo "${result}" | jq -r '.[] | @base64'
}

function JQ.item {
  local item="${1}"
  local row="${2:-$row}"
  echo "${row}" | base64 --decode | jq -r "${item}"
}

function JQ.row {
  local item="${1:-$row}"
  echo "${item}" | base64 --decode
}

function JQ.out {
  field=$1
  json=${2:-$row}
  echo "$json" | jq -r "$field"
}

function JQ.echo {
  json=$1
  field=.$2
  echo "$json" | jq -r "$field"
}

function JQ.print {
  json=$1
  field=$2
  echo "$json" | jq -r "$field"
}
