#!/bin/bash

function String.slugify {
  if Shell.has_stdin; then
    data=$(cat -)
  else
    data="$1"
  fi

  data=$(echo "$data" | tr [A-Z] [a-z] | tr '-' ' ' | tr -d '[:punct:]')
  data=$(echo "$data" | tr -d '[:digit:]')

  data=${data// as / }
  data=${data// a / }
  data=${data// so / }
  data=${data// that / }
  data=${data// i / }
  data=${data// can / }
  data=${data// me / }
  data=${data// with / }
  data=${data// and / }
  data=${data// it / }
  data=${data// do / }
  data=${data// to / }
  data=$(echo "$data" | sed -E 's/ +/-/g')

  echo "$data" | tr ' ' '-' | rev | cut -d'-' -f -5 | rev
}

function String.escape {
  data=$1
  data=${data//\\/\\\\} # \
  data=${data//\//\\\/} # /
  data=${data//\"/\\\"} # "
  data=${data//   /\\t} # \t (tab)
  data=${data//
/\\\n} # \n (newline)
  data=${data//^M/\\\r} # \r (carriage return)
  data=${data//^L/\\\f} # \f (form feed)
  data=${data//^H/\\\b} # \b (backspace)
  echo "$data"
}

function String.escape_newline {
  data=$1
  data=${data//
/\\\n} # \n (newline)
  echo "$data"
}

function String.lower {
  if Shell.has_stdin; then
    input=$(cat -)
  else
    input="$1"
  fi
  echo "$input" | tr '[:upper:]' '[:lower:]'
}

function String.encode {
  local string="${1:-}"
  local strlen=${#string}
  local encoded=""
  local pos c o

  for (( pos=0 ; pos<strlen ; pos++ )); do
     c=${string:$pos:1}
     case "$c" in
        [-_.~a-zA-Z0-9] ) o="${c}" ;;
        * )               printf -v o '%%%02x' "'$c"
     esac
     encoded+="${o}"
  done
  echo "${encoded}"
}
