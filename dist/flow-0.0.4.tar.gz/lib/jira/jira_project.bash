#!/bin/bash

function Jira::Project.all {
  Jira.get "/3/project/search?expand=url,description&status=live"
}

function Jira::Project.get {
  local key=$1

  Jira.get "/3/project/$key" \
    | jq --arg host "$JIRA_HOST" '{id: .id, key: .key, name: .name, url: "https://\($host)/secure/RapidBoard.jspa?projectKey=\(.key)",  description: .description}'
}
# https://sendoso.atlassian.net/secure/RapidBoard.jspa?projectKey=CORE

function Jira::Project::IssueType.all {
  local key=$1

  Jira.get "/3/project/$key" \
    | jq '.issueTypes[]'
}

function Jira::Project::IssueType.get {
  local key=$1 name=$2

  Jira::Project::IssueType.all "$key" \
    | jq --arg name "$name" 'select(.name | ascii_downcase == $name)'
}
