#!/bin/bash

function Jira::Me.get {
  Jira.get '/3/myself'
}

function Jira::Me.id {
  Jira::Me.get \
    | jq -r '.emailAddress'
}

function Jira::Me.account_id {
  Jira::Me.get \
    | jq -r '.accountId'
}
