#!/bin/bash

function Tracker::Project::Membership.list {
  local project_id=${1:-$(Flow.project_id)}
  local fields='person(name,initials,username)'
  local endpoint
  endpoint=$(Tracker::Project::Membership.endpoint "$project_id" "$fields")
  Tracker.get "$endpoint"
}

function Tracker::Project::Membership.endpoint {
  local project_id=$1 fields=$2
  echo "/projects/${project_id}/memberships?fields=${fields}"
}
