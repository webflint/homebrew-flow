#!/bin/bash

function Tracker::Activity::Formatter.console {
  input=$(cat)

  resources=$(echo "$input" \
   | jq '[.[].primary_resources] | flatten | unique')

  for row in $(JQ.list "${resources}"); do
    JQ.row "$row" | Tracker::Activity::Resource::Formatter.console
    echo "$input" | Tracker::Activity::Messages::Formatter.console "$(JQ.item .id)"
  done
}

function Tracker::Activity::Resource::Formatter.console {
  input=$(< /dev/stdin)

  name=$(echo "$input" | jq -r .name)
  url=$(echo "$input" | jq -r .url)

  cat <<EOF
$(Print.highlight "$name")
url:    $url
EOF
}

function Tracker::Activity::Messages::Formatter.console {
  local input
  local id=$1
  input=$(cat)
  messages=$(echo "$input" \
    | jq -r  --arg id "$id" '.[] | select(.primary_resources[].id == ($id | tonumber)) | "    \(.message)"')
  printf '\n%s\n\n' "$messages"
}
