#!/bin/bash
BASE_URL='https://www.pivotaltracker.com/services/v5'
FLOW_TRACKER_TOKEN_VAR=$(Flow::Config.get tokenvar)
FLOW_TRACKER_ENV_VAR=${FLOW_TRACKER_TOKEN_VAR:=TRACKER_TOKEN}
FLOW_TRACKER_TOKEN="${!FLOW_TRACKER_ENV_VAR:-}"
FLOW_TRACKER_BASE_HTTP_URL='https://www.pivotaltracker.com'

if [[ -z $FLOW_TRACKER_TOKEN ]]; then
  Flow.die 'Please set your FLOW_TRACKER_TOKEN enviroment variable'
fi

function Tracker.create {
  local endpoint="$1" data="$2" method='POST'

  Tracker.send "$method" "$endpoint" "$data"
}

function Tracker.update {
  local endpoint="$1" data="$2" method='PUT'

  Tracker.send "$method" "$endpoint" "$data"
}

function Tracker.get {
  local endpoint=$1
  # echo "${BASE_URL}${endpoint}"
  # NOTE: curl errors are swallowed (malformed URL)
  curl -s \
    -X GET \
    -H "X-TrackerToken: $FLOW_TRACKER_TOKEN" \
    "${BASE_URL}${endpoint}" | Tracker.trapError
}

function Tracker.send {
  local method=$1 endpoint=$2 data=$3

  curl -s \
    -X "$method" \
    "${BASE_URL}$endpoint" \
    -H "X-TrackerToken: $FLOW_TRACKER_TOKEN" \
    -H "Content-Type: application/json" \
    -d "$data" | Tracker.trapError
}

function Tracker.trapError {
  response=$(cat)
  if kind=$(JQ.echo "${response}" kind 2>/dev/null) ; then
    if [[ $kind == error ]]; then
      error=$(JQ.echo "${response}" error)
      Flow.die "${error}"
    else
      echo "$response"
    fi
  else
    echo "$response"
  fi
}
