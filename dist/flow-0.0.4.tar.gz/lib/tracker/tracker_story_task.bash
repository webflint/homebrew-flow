#!/bin/bash

function Tracker::Story::Task.list {
  declare -r story_id="$1"
  declare -r fields='tasks'
  # echo "${endpoint}?fields=${fields}"
  Tracker::Story.get "$story_id" "$fields" \
    | jq -r '.tasks[].description'
  # Tracker.get "${endpoint}?fields=${fields}"
}

function Tracker::Story::Task.create {
  local project_id
  project_id=$(Flow.project_id)
  local story_id="$1"
  local description="$2"
  local endpoint="/projects/${project_id}/stories/${story_id}/tasks"

  data="{\"description\":\"$description\"}"
  Tracker.create "$endpoint" "$data"
}

function Tracker::Story::Task.complete {
  declare incomplete_tasks
  declare -r story_id="$1"
  declare -r fields='tasks(description,complete)'
  local tasks
  tasks=$(Tracker::Story.get "$story_id" "$fields")

  incomplete_tasks=$(echo "$tasks" \
    | jq '[ .tasks[] | select(.complete == false)]')

  descriptions=$(echo "$incomplete_tasks" \
    | jq -r '.[].description')
  # echo "$tasks" | jq '.tasks[0]'
  PS3='Choose the Task to complete (q) to quit: '
  old_IFS=$IFS
  IFS=$'\n'
  select ch in $descriptions
  do
    # echo "You have chosen $ch!"
    index="$((REPLY - 1))"
    break
  done
  IFS=${old_IFS}

  echo "$incomplete_tasks" | jq --arg index $index '.[($index | tonumber)]'
}
