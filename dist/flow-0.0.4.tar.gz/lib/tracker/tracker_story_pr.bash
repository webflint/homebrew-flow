#!/bin/bash

function Tracker::Story::Pr.list {
  local story_id=$1
  json=$(Tracker::Story.get "${story_id}" pull_requests)
  list=$(echo "${json}" | jq -r '.pull_requests[] | @base64')
  # shellcheck disable=SC2034
  for row in $list; do
    owner=$(JQ.item .owner)
    repo=$(JQ.item .repo)
    number=$(JQ.item .number)
    Github::Pr.url "${owner}" "${repo}" "${number}"
  done
}
