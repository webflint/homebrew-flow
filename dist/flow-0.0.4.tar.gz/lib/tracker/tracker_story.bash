#!/bin/bash


function Backend::Story.valid_id {
  Integer.valid "$1"
}

function Tracker::Story.branch_name {
  json=$1
  id=$(JQ.echo "$json" id)
  name=$(JQ.echo "$json" name)
  story_type=$(JQ.echo "$json" story_type)
  slug=$(String.slugify "$name")
  echo "$story_type/$id/$slug"
}

function Tracker::Story.get {
  local default_fields="id,url,name,current_state,story_type,estimate,description,owners(name,initials),requested_by(name,initials),project(name),cycle_time_details,labels(name),pull_requests"
  declare id=${1}
  if Url.valid "$id"; then
    id=$(echo "$id" | rev | cut -d'/' -f1 | rev)
  fi
  declare -r fields=${2:-$default_fields}
  Tracker.get "/stories/$id?fields=${fields}"
}

function Tracker::Story.new {
  declare markdown data
  declare -r project_id=${1}
  declare -r story_type=${2:-feature}
  # shellcheck source=/dev/null
  . "$FLOW_BASE_DIR/lib/tracker_story_template.bash"
  case $story_type in
    'feature')
      markdown=$(Tracker::Story::Template.feature)
    ;;
    'bug')
      markdown=$(Tracker::Story::Template.bug)
    ;;
    'chore')
      markdown=$(Tracker::Story::Template.chore)
    ;;
  esac
  data=$(Flow.modify "$markdown" "flow new story") || return 100
  data=$(echo "${data}" | jq --arg story_type "${story_type}" '. + {story_type: $story_type}')
  Tracker::Story.create "${project_id}" "${data}"
}

function Tracker::Story.edit {
  story_id=$1
  json=$(Tracker::Story.get "${story_id}")
  markdown=$(Tracker::Story::Formatter.markdown "${json}")
  data=$(Flow.modify "$markdown" "flow edit story") || return 100
  Tracker::Story.update "${story_id}" "${data}"
}

function Tracker::Story.create {
  local project_id=$1
  local data=$2
  local endpoint="/projects/$project_id/stories"
  Tracker.create "${endpoint}" "${data}"
}

function Tracker::Story.update {
  local id=$1
  local data=$2
  local endpoint="/stories/${id}"
  local cache_key="Tracker::Story.get $id"
  local story
  story=$(Tracker.update "${endpoint}" "${data}") \
    && Flow::Cache.set "$cache_key" "$story"
}

function Tracker::Story.activity {
  local story_id=$1
  local after=$2
  local endpoint
  local fields=:default

  local project_id
  story=$(Tracker::Story.get "$story_id" "project(id)")
  project_id=$(echo "$story" | jq -r .project.id)

  endpoint="/projects/$project_id/stories/$story_id/activity?fields=${fields}&occurred_after=$after"
  Tracker.get "$endpoint"
}

function Backend::Story.show {
  Tracker::Story.get "${story_id}" \
    | Tracker::Story::Formatter::Console.detail
}