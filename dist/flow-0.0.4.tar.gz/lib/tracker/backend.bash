#!/bin/bash

function Backend::Config.story_matcher {
  echo "^[0-9]+$"
}

function Backend::Me.id {
  Tracker::Me.id
}

function Backend::Me.wip {
  person_id=$1
  Tracker::My.wip "$person_id" \
    | Tracker::Story::Formatter::Console.list_detail
}

function Backend::Me.get {
  # me_id=${1:-$(Tracker::Me.id)}
  local fields='name,initials,username,email'
  Tracker::Me.get "${fields}" \
    | jq -r '"\(.id) \(.initials) \(.username) \(.email) \(.name)"'
}

function Backend::Project.list {
  Tracker::Project.list
}

function Backend::Project.get {
  local id=$1

  Tracker::Project.get "$id"
}
