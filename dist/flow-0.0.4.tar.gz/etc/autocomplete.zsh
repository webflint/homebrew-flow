function _flow_autocomplete() {
  local flow_cmd_dir match_command commands command_index results

  match_command=${(j:-:)words}
  flow_cmd_dir="$FLOW_BASE_DIR/libexec/"
  commands=$(find "${flow_cmd_dir}" -name "$match_command*" -maxdepth 1 | rev | cut -d'/' -f1 | rev)
  command_index=${#words[@]}
  results=$(echo "$commands" | cut -d'-' -f"$command_index" | grep . | uniq)
  array_of_results=("${(@f)results}")
  _describe 'command' array_of_results
}

compdef _flow_autocomplete flow
