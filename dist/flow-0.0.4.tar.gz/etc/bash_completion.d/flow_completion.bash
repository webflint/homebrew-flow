#!/bin/bash

# References
# https://iridakos.com/tutorials/2018/03/01/bash-programmable-completion-tutorial.html
# how to install:
#   https://docs.docker.com/compose/completion/

function _flow_completions {
  function find_flow_dir {
    local dir source="${BASH_SOURCE[0]}"
    while [ -h "$source" ]; do # resolve $source until the file is no longer a symlink
      dir="$( cd -P "$( dirname "$source" )" && pwd )"
      source="$(readlink "$source")"
      [[ $source != /* ]] && source="$dir/$source" # if $source was a relative symlink, we need to resolve it relative to the path where the symlink file was located
    done
    cd -P "$(dirname "$source")/../.." && pwd
  }
  export FLOW_BASE_DIR=$(find_flow_dir)

  FLOW_CMD_DIR="$FLOW_BASE_DIR/libexec"

  # shellcheck source=/dev/null
  . "$FLOW_BASE_DIR/libexec/_lib-package.bash"

  current_word=${COMP_WORDS[$COMP_CWORD]}

  if [[ ${current_word:0:1} == '@' ]]; then
    local at_mention=1
  fi

  if [ -n "$at_mention" ]; then
    # NOTE: for now this only autocompletes on membership of the current project
    # needs better cache to support `flow my people`
    # cause we get `fork: retry: Resource temporarily unavailable` right now
    # when we mash tab
    members=$(flow cache project people)

    usernames=$(echo "$members" \
      | cut -d' ' -f 3)

    IFS=$'\n' read -d '' -r -a suggestions <<< "$usernames"

    result=( $(compgen -W "${suggestions[*]}" "$current_word") )

    # Works inside the quoted string but complete adds the closing quote
    # if [[ ${#result[@]} -eq 1 ]]; then
    #   COMPREPLY+=( "$sentence ${result[*]} what?" )
    # else
    #   COMPREPLY+=( "${result[@]}" )
    # fi
    COMPREPLY+=( "${result[@]}" )

  else
    commands=$(find "${FLOW_CMD_DIR}" -maxdepth 1 | rev | cut -d'/' -f1 | rev)
    command_string=$(Array.join - "${COMP_WORDS[@]}")
    matches="$(compgen -W "${commands[@]}" "$command_string")"
    command_index=$(( 1 + COMP_CWORD ))
    commands=$(echo "$matches" | cut -d'-' -f"$command_index" | uniq)
    IFS=$'\n' read -d '' -r -a suggestions <<< "$commands"
    COMPREPLY+=("${suggestions[@]}")
  fi
}

complete -F _flow_completions flow
