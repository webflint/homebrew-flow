#!/bin/bash

function Flow::Config.key {
  declare name lowercased
  name=${1}
  lowercased=$(String.lower "${name}")
  echo "flow.${lowercased}"
}

function Flow::Config.set {
  declare name value setting
  name=${1}
  value=${2}
  setting=$(Flow::Config.key "${name}")
  git config --local "${setting}" "${value}"
}

function Flow::Config.get {
  declare name setting
  name=${1}

  if [[ -z $name ]]; then
    git config -l | grep '^flow\.'
  else
    setting=$(Flow::Config.key "${name}")
    git config "${setting}" || echo ''
  fi
}
