#!/bin/bash

function JSON.empty {
  [[ $1 == '[]' ]]
}
