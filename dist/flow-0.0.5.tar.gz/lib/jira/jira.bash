#!/bin/bash

JIRA_WWW_URL="https://$JIRA_HOST"
JIRA_BASE_URL="$JIRA_WWW_URL/rest/api"

function Jira.token {
  echo -n "$JIRA_USER_NAME:$JIRA_AUTH_TOKEN" | base64
}

function Jira.create {
  local endpoint="$1" data="$2" method='POST'

  Jira.send "$method" "$endpoint" "$data"
}

function Jira.update {
  local endpoint="$1" data="$2" method='POST'

  Jira.send "$method" "$endpoint" "$data"
}

function Jira.get {
  local endpoint=$1
  # echo "${BASE_URL}${endpoint}"
  # NOTE: curl errors are swallowed (malformed URL)
  auth_token=$(Jira.token)

  curl -s \
    -X GET \
    -H "Authorization: Basic $auth_token" \
    "${JIRA_BASE_URL}${endpoint}" | Jira.trapError
}

function Jira.send {
  local method=$1 endpoint=$2 data=$3 auth_token

  auth_token=$(Jira.token)

  curl -s \
    -X "$method" \
    "${JIRA_BASE_URL}$endpoint" \
    -H "Authorization: Basic $auth_token" \
    -H "Content-Type: application/json" \
    -d "$data" | Jira.trapError
}

function Jira.trapError {
  response=$(cat)
  if kind=$(JQ.echo "${response}" kind 2>/dev/null) ; then
    if [[ $kind == error ]]; then
      error=$(JQ.echo "${response}" error)
      Flow.die "${error}"
    else
      echo "$response"
    fi
  else
    echo "$response"
  fi
}
