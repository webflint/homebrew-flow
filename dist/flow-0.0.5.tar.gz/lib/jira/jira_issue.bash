#!/bin/bash

function Jira::Issue::Transitions.all {
  local id=$1
  local url="/3/issue/$id/transitions"

  Jira.get "$url"
}

function Jira::Issue::Transitions.get {
  local id=$1 state=$2
  local config_mapping

  config_mapping=$(Flow::Config.get "state.$state")
  state=${config_mapping:-$state}

  Jira::Issue::Transitions.all "$id" \
    | jq -r --arg state "$state" '.transitions[] | select(.name | ascii_downcase == $state)'
}
