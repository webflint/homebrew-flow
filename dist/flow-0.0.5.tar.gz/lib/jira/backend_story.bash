#!/bin/bash

function Backend::Story.valid_id {
  matcher=$(Backend::Config.story_matcher)
  [[ $1 =~ $matcher ]]
}

function Backend::Story.create {
  local project_key=$1 story_type=$2

  data=$(Flow.modify "" "flow new story") || return 100

  if [ "$story_type" == "feature" ]; then
    story_type=story
  fi
  type_id=$(Jira::Project::IssueType.get "$project_key" "$story_type" | jq -r '.id')
  if [ -z "$type_id" ]; then
    Flow.die "Story type can not be found: $story_type"
  fi

  data=$(echo "$data" | jq --arg project_key "$project_key" --arg type_id "$type_id" '{fields: {issuetype: {id: $type_id}, project: { key: $project_key}, summary: .name, description: { type: "doc", version: 1, content: [{type: "paragraph", content: [{type: "text", text: .description}]}]}}}')

  Jira.update "/3/issue" "$data" \
    | jq --arg host "$JIRA_HOST" '{id: .key, url: "https://\($host)/browse/\(.key)"}'
}

function Backend::Story.get {
  local id=$1

  Jira.get "/3/issue/$id"
}

function Backend::Story.state {
  local id=$1 state

  state=$(Backend::Story.get "$id" | jq -r '.fields.status.name' | String.lower)

  case "$state" in
    "in progress")
      echo "Started"
    ;;

    "code review")
      echo "Finished"
    ;;

    "internal qa")
      echo "Delivered"
    ;;

    "ready to push live")
      echo "Accepted"
    ;;

    "done")
      echo "Done"
    ;;

    *)
      echo "**$state**"
    ;;
  esac
}

function Backend::Story.show {
  local id=$1

  Jira.get "/3/issue/${id}" \
    | jq --arg url "$JIRA_WWW_URL" '{id: .id, url:"\($url)/browse/\(.key)", type: .fields.issuetype.name, summary: .fields.summary, status: .fields.status.name}'
}

function Backend::Story.accept {
  id=$1
  Flow.die "Not Implemented"
}

function Backend::Story.title {
  id=$1
  data=$(Backend::Story.get "$id")
  title=$(echo "$data" | jq -r '.fields.summary')
  echo "$title"
}

function Backend::Story.description {
  id=$1
  data=$(Backend::Story.show "$id")
  description=$(echo "$data" | sed -e '1,/description: |/d')
  echo "$description"
}

function Backend::Story.url {
  local id=$1
  echo "$JIRA_WWW_URL/browse/$id"
}

function Backend::Story.branch_name {
  local id=$1
  story=$(Backend::Story.get "$id")
  title=$(echo "$story" | jq -r '.fields.summary')
  type=$(echo "$story" | jq -r '.fields.issuetype.name' | String.lower)
  slug=$(String.slugify "$title")

  echo "$type/$id/$slug"
}

function Backend::Story.start {
  local id=$1
  local data

  transition_id=$(Jira::Issue::Transitions.get "$id" started | jq -r '.id')
  if [ -z "$transition_id" ]; then
    Flow.die 'Could not find a JIRA transition for started'
  fi

  data="{\"transition\":{\"id\":\"$transition_id\"}}"
  Jira.update "/3/issue/${id}/transitions" "$data"
}

function Backend::Story.finish {
  local id=$1
  local data transition_id

  transition_id=$(Jira::Issue::Transitions.get "$id" finished | jq -r '.id')
  if [ -z "$transition_id" ]; then
    Flow.die 'Could not find a JIRA transition for finished'
  fi

  data="{\"transition\":{\"id\":\"$transition_id\"}}"
  Jira.update "/3/issue/${id}/transitions" "$data"
}

function Backend::Story.deliver {
  local id=$1
  local data transition_id

  transition_id=$(Jira::Issue::Transitions.get "$id" delivered | jq -r '.id')
  if [ -z "$transition_id" ]; then
    Flow.die 'Could not find a JIRA transition for delivered'
  fi

  data="{\"transition\":{\"id\":\"$transition_id\"}}"
  Jira.update "/3/issue/${id}/transitions" "$data"
}

function Backend::Story.assign {
  local id=$1
  local account_id data

  account_id=$(Jira::Me.account_id)
  data="{\"accountId\":\"$account_id\"}"

  Jira.send PUT "/3/issue/${id}/assignee" "$data"
}

function Backend::Story::Branch.list {
  local story_id=$1

  Git::Branch.find_remote "/$story_id/"
}
