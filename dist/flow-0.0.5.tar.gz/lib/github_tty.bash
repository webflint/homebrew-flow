#!/bin/bash

function Github::Tty.pr {
  input=$(< /dev/stdin)
  row=$(echo "$input" | jq .data.repository.pullRequest)
  title=$(echo "$row" | jq -r .title)
  url=$(echo "$row" | jq -r .url)
  closed=$(echo "$row" | jq -r .closed)
  status=$(echo "$row" | jq -r .mergeable)
  merge_status=$(echo "$row" | jq -r .mergeStateStatus)
  comments=$(echo "$row" | jq -r .comments.totalCount)
  reviews=$(echo "$row" | jq -r .comments.totalCount)
  reviews=$(JQ.out '.reviews.totalCount')
  reviewRequests=$(JQ.out '.reviewRequests.totalCount')

  cat <<EOF
$(Print.highlight "$title")
url:          $url
closed:       $closed
status:       $merge_status,$status
reviews:      $reviews/$reviewRequests
comments:     $comments
EOF
}
