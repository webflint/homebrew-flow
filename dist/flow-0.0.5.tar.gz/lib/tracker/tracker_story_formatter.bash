#!/bin/bash

function Tracker::Story::Formatter::Console.detail {
  input=$(< /dev/stdin)
  local url name type state description total_cycle_time total_cycle_time_days
  url=$(JQ.print "$input" .url)
  name=$(JQ.print "$input" .name)
  type=$(JQ.print "$input" .story_type)
  state=$(JQ.print "$input" .current_state)
  owners=$(echo "$input" | jq -j '.owners[] | "\(.name) (\(.initials)) "')
  requester=$(echo "$input" | jq -r '.requested_by | "\(.name) (\(.initials))"')
  project_name=$(echo "$input" | jq -r '.project.name')
  labels=$(echo "$input" | jq -j '.labels[] | "#\(.name) "')
  description=$(JQ.print "$input" .description)
  total_cycle_time=$(echo "$input" | jq -r '.cycle_time_details.total_cycle_time')
  if [[ $total_cycle_time != null ]]; then
    total_cycle_time_days="$(echo "scale=2; $total_cycle_time/(1000 * 60 * 60 * 24)" | bc) days"
  else
    total_cycle_time_days=''
  fi
  total_time_in_state=$(echo "$input" | jq --arg state "${state}_time" -r '.cycle_time_details | .[$state]')
  if [[ $total_time_in_state != null ]]; then
    total_time_in_state_days="($(echo "scale=2; $total_time_in_state/(1000 * 60 * 60 * 24)" | bc) days)"
  else
    total_time_in_state_days=''
  fi
  pull_request_args=($(echo "$input" | jq -r '.pull_requests[] | "\(.owner) \(.repo) \(.number)"'))
  if [[ ${#pull_request_args[@]} -eq 0 ]]; then
    pull_request=''
    total_time_in_state_days="($(echo "scale=2; $total_time_in_state/(1000 * 60 * 60 * 24)" | bc) days)"
  else
    pull_request=$(Github::Pr.url "${pull_request_args[@]}")
  fi

  echo -e "$(Print.highlight "$name")"
  echo -e url:'\t\t'"$url"
  echo -e project:'\t'"$project_name"
  echo -e labels:'\t\t'"$labels"
  echo -e type:'\t\t'"$type"
  echo -e requester:'\t'"$requester"
  echo -e owners:'\t\t'"$owners"
  echo -e state:'\t\t'"$state $total_time_in_state_days"
  if [[ -n $pull_request ]]; then
    echo -e pull request:'\t'"$pull_request"
  fi
  echo -e cycle time:'\t'"$total_cycle_time_days"
  echo
  if [[ $description != null ]]; then
    echo -e "$description"
  fi
}

function Tracker::Story::Formatter::Console.list_detail {
  input=$(< /dev/stdin)
  for row in $(JQ.list "${input}"); do
    JQ.row "$row" | Tracker::Story::Formatter::Console.detail
    Print.hr
  done
}

function Tracker::Story::Formatter::Console.list {
  jq -r 'to_entries  | map(.value) | flatten | .[] | "\(.url) \(.name)"'
}

function Tracker::Story::Formatter.markdown {
  local json=$1

  cat << EOF
$(JQ.echo "$json" name)
$(echo -e "$(JQ.echo "$json" description)")
EOF
}