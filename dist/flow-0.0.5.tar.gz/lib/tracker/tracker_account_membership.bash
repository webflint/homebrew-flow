#!/bin/bash

function Tracker::Account::Membership.list {
  local account_id=$1
  # local fields='person(name,initials,username)'
  Tracker.get "/accounts/$account_id/memberships"
}

function Tracker::Account::Membership.find_by_initials {
  local account_id=$1
  local initials=$2
  Tracker::Account::Membership.list "$account_id" \
    | jq --arg initials "$initials" '.[] | select(.person.initials==$initials) | .id'
}

function Tracker::Account::Membership.find_by_username {
  local account_id=$1
  local username=$2
  is_at_mention=$(echo "$username" | cut -c1)
  if [[ $is_at_mention == @ ]]; then
    username=$(echo "$username" | cut -d "@" -f 2)
  fi

  Tracker::Account::Membership.list "$account_id" \
    | jq --arg username "$username" '.[] | select(.person.username==$username) | .id'
}
