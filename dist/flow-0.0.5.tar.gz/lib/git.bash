#!/bin/bash

function Git::Repo.name {
  local field
  if Git::Origin.is_ssh; then
    field=2
  else
    field=5
  fi
  Git::Remote.url 'origin' | cut -d'/' -f "$field" | cut -d'.' -f1
}

function Git::Repo.owner {
  if Git::Origin.is_ssh; then
    Git::Remote.url 'origin' | cut -d':' -f2 | cut -d'/' -f1
  else
    Git::Remote.url 'origin' | cut -d'/' -f4
  fi
}

function Git::Branch.name {
  git rev-parse --abbrev-ref HEAD 2>/dev/null
}

function Git::Branch.find {
  local string=$1
  branch=$(Git::Branch.find_local "$string")
  if [[ -z $branch ]]; then
    branch=$(Git::Branch.find_remote "$string")
  fi
  echo "$branch"
}

function Git::Branch.find_local {
  local string=$1
  git_branch_name=$(git branch | grep "$string" | head -n1 | xargs)
  echo "$git_branch_name"
}

function Git::Branch.find_remote {
  local string=$1
  git fetch &>/dev/null
  git_branch_name=$(git branch -a | grep "$string" | head -n1 | xargs)
  echo "${git_branch_name#remotes/origin/}"
}

function Git::Branch.ahead_by {
  local branch_name=${1:-master}
  git rev-list --left-right --count ..."$branch_name" | cut -d$'\t' -f1
}

function Git.story_id {
  declare branch_name result
  branch_name=${1:-$(Git::Branch.name)}
  result=$(echo "$branch_name" | Backend::Config.branch_name_parser)
  matcher=$(Backend::Config.story_matcher)
  if [[ $result =~ $matcher ]]; then
    echo "$result"
  else
    return 1
  fi
}

function Git::Remote.url {
  name=${1:-}
  git config --get "remote.${name}.url"
}

function Git::Origin.is_ssh {
  prefix=$(Git::Remote.url origin | cut -d':' -f1)
  [ "$prefix" == 'git@github.com' ]
}
